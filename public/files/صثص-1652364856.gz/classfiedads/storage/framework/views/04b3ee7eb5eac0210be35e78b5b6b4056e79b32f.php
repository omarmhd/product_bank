<footer class="mt-5">
    <p>Footer</p>
</footer><?php /**PATH /opt/lampp/htdocs/classfiedads/resources/views/partials/footer.blade.php ENDPATH**/ ?>