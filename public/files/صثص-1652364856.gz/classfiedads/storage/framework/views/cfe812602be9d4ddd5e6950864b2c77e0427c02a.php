<?php $__env->startSection('title', 'رئيسية الموقع'); ?>        
<?php $__env->startSection('content'); ?>
    <h1>الصفحة الرئيسية</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/classfiedads/resources/views/index.blade.php ENDPATH**/ ?>