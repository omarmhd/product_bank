<footer class="mt-5">
    <p>Footer</p>
</footer>