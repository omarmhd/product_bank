<ul class="nav justify-content-center">
    <li class="nav-item nav-link">   عقارات  </li>
    <li class="nav-item nav-link">   إلكترونيات </li>
    <li class="nav-item nav-link">   أثاث </li>

</ul>