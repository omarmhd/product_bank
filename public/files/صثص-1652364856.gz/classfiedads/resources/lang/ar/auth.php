<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'failed' => 'البيانات المدخلة غير صحيحة.',
    'password' => 'كلمة السر خاطئة.',
    'throttle' => 'اجريت عدد محاولات اكثرةمن الازم حاول في وقت اخر.',
    'Login' => 'دخول',
    'Register' => 'تسجيل الدخول',
    'name' => 'الاسم',
    'E-Mail Address' => 'البريد الالكتروني',
    'Password' => 'كلمة السر',
    'Confirm Password' => 'تأكيد كلمة السر',
    'Remember Me' => 'تذكرني',
    'Forgot Your Password?' => 'نسيت كلمة السر؟',
    'Name' => 'الاسم'

];
