<footer>
    <div class="container">
        <div class="footer">
            <div>
                <a href="#">
                    <img src="images/logo.svg" alt="" srcset="">
                </a>
                <div class="copyright">جميع الحقوق محفوظة © علم 2021</div>
                <div>
                    <a href="#">English</a>
                    <a href="#">تواصل معنا</a>
                </div>
            </div>
        </div>
    </div>

</footer>
<?php /**PATH F:\2021\مشاريع واعمال\بنك المنتجات\products_bank\resources\views/layout/_footer.blade.php ENDPATH**/ ?>