<!DOCTYPE html>
<html lang="ar" dir="rtl">

<?php echo $__env->make('layout._head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<body>
<style>
    .home .content .bottom .card-1 .body-card h1{
        word-break: break-all;
    }
    @media(max-width:419px){
        .home .content .top .filter{
            margin-top: 20px;
            margin-bottom: 20px;
        }
        .home .content .top {
            flex-flow: column;
        }
        .home .content .top .number-project{
            font-size:18px;
        }
        footer .footer > div {
            display: flex;
            align-items: center;
            flex-direction: column;
            margin-bottom: 20px;
        }
        .home .content .top .filter select{
            width: 100%;

        }

    }
    @media(max-width:992px){
        .aside-bar-menu .search i {
            transform: translate(0%, 0%);
        }
    }
</style>

<?php echo $__env->make('layout.modals.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.modals.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="se-pre-con"></div>

<?php echo $__env->make('layout._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">

    <?php echo $__env->yieldContent('content'); ?>
</div>



<?php echo $__env->make('layout._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>



<?php echo $__env->make('layout._script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldPushContent('js'); ?>
<?php echo $__env->make('layout.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</html>
<?php /**PATH F:\مشاريع واعمال\بنك المنتجات\products_bank\resources\views/layout/app.blade.php ENDPATH**/ ?>