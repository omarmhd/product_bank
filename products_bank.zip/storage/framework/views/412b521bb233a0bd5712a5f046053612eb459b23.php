<div class="modal fade" id="filter" tabindex="-1"  role="dialog" aria-labelledby="loginTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close text-right" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="filter-form" action="javascript:void(0)">
                    <div class="row ">
                        <div class="col-12">
                            <h3></h3>
                            <p></p>
                        </div>
                        <div class="col-5" style="text-align:right">

                                <label for=""> صحة المشروعة</label>
                                <select name="" id="" class="project-health">
                                    <option value="عالية">عالية</option>
                                    <option value="ضعيفة">ضعيفة</option>

                                </select>

                        </div>
                    <div class="col-5 " style="text-align:right">

                                <label for=""> حالة المشروع</label>
                                <select name="" id="" class="project-status">
                                    <option value="قيد التنفيذ">قيد التنفيذ</option>
                                    <option value="تم التنفيذ">تم التنفيذ</option>
                                    <option value="معلق">معلق</option>
                                    <option value="مغلق">مغلق</option>

                                </select>


                    </div>



                        <div class="col-12 mt-4">
                            <button type="submit" class="btn btn-info"><i class="fa fa-search"></i> بحث</button>
                        </div>



                    </div>
                </form>
            </div>

        </div>
    </div>
</div>
<div class="side-overlay"></div>
<?php /**PATH F:\2021\مشاريع واعمال\بنك المنتجات\products_bank\resources\views/layout/modals/filter.blade.php ENDPATH**/ ?>