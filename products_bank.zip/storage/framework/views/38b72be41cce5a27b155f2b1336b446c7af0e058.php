<?php $__env->startSection('content'); ?>

    <section class="home bg-container">
                    <div class="content">
                        <div class="top">
                            <?php if(isset($search)): ?>
                                <div class="number-project">نتائج البحث عن :
                                    <p><?php echo e($search); ?></p>
                                </div>

                            <?php else: ?>

                                <div class="number-project"> عدد المشاريع :  <?php echo e($count); ?> </div>
                                <div class="filter">
                                    <a href="#" data-toggle="modal" data-target="#filter"> <i class="fa fa-sliders" aria-hidden="true"></i></a>
                                    <select name="sort" class="sort">
                                        <option selected disabled>الترتيب حسب</option>
                                        <option value="oldest"> الأقدم </option>
                                        <option value="latest"> الأحدث </option>
                                    </select>
                                </div>
                            <?php endif; ?>


                        </div>
                        <div class="bottom">
                            <div class="row projects" >

                                <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                <div class="col-md-6 mb-4">
                                    <?php if(isset($type_page)): ?>
                                        <a href="<?php echo e(route('project.edit',['project'=>$project->id])); ?>">

                                        <?php else: ?>
                                  <a href="<?php echo e(route('project.show',['project'=>$project->id])); ?>">

                               <?php endif; ?>
                                        <div class="card-1">
                                            <figure>
                                                <img src="<?php echo e(asset('files')); ?>/<?php echo e($project->image); ?>" class='img-fluid' alt="" srcset="">
                                            </figure>
                                            <div class="body-card">
                                                <h1><?php echo e($project->name); ?></h1>
                                                <p><?php echo e($project->description); ?></p>
                                            </div>
                                            <div class="footer-card">
                                                <span>حالة المشروع: <?php echo e($project->status); ?> </span>
                                                <span> صحة المشروع : <?php echo e($project->project_health); ?></span>
                                            </div>
                                        </div>
                                    </a>
                                        </a>
                                </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                   <H3>  لا يوجد نتائج </H3>
                                <?php endif; ?>

                            </div>

                        </div>
                    </div>
            </section>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>
    <script>


        $(document).ready(function(){


            $('.sort').change(function (){


                filter( $(this).val(),project_health="",project_status="")

            });


            $('.filter-form').submit(function (e){
                e.preventDefault()

                var sort=$('.sort').val()||"";
                var project_health=$('.project-health').val()||"";
                var project_status=$('.project-status').val()||"";

                filter(sort,project_health, project_status)

            })







            function filter(date="",project_health="",project_status=""){
                console.log(date)
                console.log(project_health)
                $.ajax({
                    url:"<?php echo e(route('project.filter')); ?>" ,
                    type: "get",
                    data:{
                        date: date,
                        project_health: project_health,
                        project_status: project_status,
                    },


                    success: (data) => {
                        $('.projects').empty()
                        var projects = JSON.parse( JSON.stringify(data.projects));

                        $.each(projects,function(index, value){
                            var url="<?php echo e(route('project.edit',['project'=>":project"])); ?>"
                            url =url.replace(':project',value.id)




                            $('.projects').append(
                                `  <div class="col-md-6 mb-4">
                                    <a href=`+url+`>
                                        <div class="card-1">
                                            <figure>
                                                <img src="<?php echo e(asset('files')); ?>/`+value.image+`" class='img-fluid' alt="" srcset="">
                                            </figure>
                                            <div class="body-card">
                                                <h1>`+value.name+`</h1>
                                                <p>`+value.description+`</p>
                                            </div>
                                            <div class="footer-card">
                                                <span>حالة المشروع: `+value.status+`</span>
                                                <span> صحة المشروع : `+value.project_health+`</span>
                                            </div>
                                        </div>
                                    </a>
                                </div>`
                            )
                        });

                    }
                })
            }


        })

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\مشاريع واعمال\بنك المنتجات\products_bank\resources\views/index.blade.php ENDPATH**/ ?>