<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>بنك المنتجات</title>
    <link rel="stylesheet" href="<?php echo e(asset('asset')); ?>/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('asset')); ?>/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('asset')); ?>/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" integrity="sha512-vKMx8UnXk60zUwyUnUPM3HbQo8QfmNx7+ltw8Pm5zLusl1XIfwcxo8DbWCqMGKaWeNxWA8yrx5v3SaVpMvR3CA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.2/css/jquery.dataTables.min.css">
    <style>
        .validation-error-message {
            color:#FF0000;  /* red */
            font-size: 4px;

        }
        .my-valid-class {
            color:#00CC00; /* green */
            display: block;

        }
    </style>
    <?php echo $__env->yieldPushContent('css'); ?>
</head>
<?php /**PATH F:\مشاريع واعمال\بنك المنتجات\products_bank\resources\views/layout/_head.blade.php ENDPATH**/ ?>