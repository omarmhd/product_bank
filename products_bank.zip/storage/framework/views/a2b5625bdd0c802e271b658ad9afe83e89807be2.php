<?php if(session('success')): ?>

    <script>

        Swal.fire({
            position: 'center',
            icon: 'success',
            title:"<?php echo e(session('success')); ?>",
            showConfirmButton: false,
            timer: 2000
        })
    </script>
<?php elseif(session('error')): ?>
    <script>

        Swal.fire({
            position: 'center',
            icon: 'error',
            title:"<?php echo e(session('error')); ?>",
            showConfirmButton: false,
            timer: 2000
        })
    </script>

<?php endif; ?>
<?php /**PATH F:\2021\مشاريع واعمال\بنك المنتجات\products_bank\resources\views/layout/messages.blade.php ENDPATH**/ ?>