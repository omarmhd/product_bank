<?php $__env->startSection('content'); ?>
        <div class="log bg-container">
            <div class="row">
                <div class="col-lg-8 mx-auto">
                    <div class="input-section mt-4">
                        <h2>التدقيق</h2>
                        <p>يمكنك رؤية جميع التغييرات التي حصلت على مشروعك  </p>
                        <div class="table-responsive">


                            <table class="display" id="table_id">
                                <thead>
                                <tr>
                                    <th>التاريخ</th>
                                    <th>رقم المشروع</th>
                                    <th>التعديل</th>
                                    <th>ملاحظات</th>

                                </tr>
                                </thead>
                                <tbody>

                                <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($log->created_at); ?></td>
                                    <td><?php echo e($log->project_id); ?></td>
                                    <td><?php echo e($log->event); ?></td>
                                    <td colspan="2"><?php echo e($log->note); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>

                        </div>



                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>



        $(document).ready( function () {
            $('#table_id').DataTable({
                "pagingType": "simple",
                "language": {
                    "search": "بحث:",
                    "lengthMenu": "  عرض _MENU_في الصفحة الواحدة   ",
                    "info": "الصفحة  _PAGE_ من _PAGES_",
                    "zeroRecords": "نأسف ,لايوجد أي شىء",
                    "infoFiltered": "( تمت تصفيته من إجمالي _MAX_السجلات)"

                }

            });
        } );

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\2021\مشاريع واعمال\بنك المنتجات\products_bank\resources\views/log.blade.php ENDPATH**/ ?>