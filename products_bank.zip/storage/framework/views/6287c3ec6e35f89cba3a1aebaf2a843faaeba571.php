<!-- Modal -->
<div class="modal fade" id="login" tabindex="-1"  role="dialog" aria-labelledby="loginTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close text-right" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form method="post" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>

                <div class="row">

                        <div class="col-12">
                            <h3>تسجيل الدخول</h3>
                            <p>سجل دخولك لإضافة المشروع الخاص بك</p>
                        </div>
                    <div class="col-12">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                    </div>
                        <div class="col-12">
                            <div class="custom-input mb-3">













                                <input type="name"  name="name" class="input-text-custom form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="name">

                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="custom-input ">











                                <input type="password" name="password" class="input-text-custom form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="كلمة المرور">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>
                        </div>

                        <div class="d-flex justify-content-between flex-wrap mx-auto mb-3 col-lg-6">
                            <div class="reset-padding-col">
                                <div class="custom-checkbox">
                                    <input type="checkbox" id="remember">
                                    <span class="checkmark"></span>
                                    <label for="remember">تذكرني</label>
                                </div>



                                <!-- <label for="rembmer-me">تذكرني</label> -->

                            </div>
                            <div class="reset-padding-col">
                                <a href="#">
                                    نسيت كلمة المرور
                                </a>
                            </div>
                        </div>

                        <div class="col-12">
                            <button type="submit" class="btn btn-custom-login">دخول</button>
                        </div>



                </div>
                </form>
            </div>

        </div>
    </div>
</div>
<div class="side-overlay"></div>
<?php /**PATH F:\مشاريع واعمال\بنك المنتجات\products_bank\resources\views/layout/modals/login.blade.php ENDPATH**/ ?>